package com.guessThenNumber.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.guessTheNumber.model.Game;

@Repository
@Profile("database")
public class GuessTheNumberDatabaseDAO implements GuessTheNumberDAO {

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public GuessTheNumberDatabaseDAO( JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate=jdbcTemplate;		
	}

	@Override
	public Game addNewGame(Game game) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Game> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Game resumeGame(int gameID) {
		// TODO Auto-generated method stub
		return null;
	}

}
