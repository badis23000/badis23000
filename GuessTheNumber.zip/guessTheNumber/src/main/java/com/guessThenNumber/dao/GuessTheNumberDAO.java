package com.guessThenNumber.dao;

import java.util.List;

import com.guessTheNumber.model.Game;

public interface GuessTheNumberDAO {
Game addNewGame(Game game);
List<Game> getAll();
Game resumeGame(int gameID);
}
