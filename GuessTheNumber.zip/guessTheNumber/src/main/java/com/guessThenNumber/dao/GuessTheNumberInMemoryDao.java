package com.guessThenNumber.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import com.guessTheNumber.model.Game;

@Repository
@Profile("in_memory")
public class GuessTheNumberInMemoryDao implements GuessTheNumberDAO {
	
	private static final List<Game> games = new ArrayList();


	@Override
	public Game addNewGame(Game game) {
		 int nextId = games.stream()
	             .mapToInt(i -> i.getGameID())
	             .max()
	             .orElse(0)+1;
	     game.setGameID(nextId);
	     games.add(game);
		return game;
	}

	@Override
	public List<Game> getAll() {
		return this.games;
	}

	@Override
	public Game resumeGame(int gameID) {
		return null;
	}

}
