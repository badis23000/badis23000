package com.guessTheNumber.model;

import java.util.Arrays;
import java.util.Random;


public class Game {
	private int gameID;
	private int[] numberToGuess;
	private int[] guessedNumber;
	private int partial;
	private int correct;
	private boolean status;

	public Game(int gameID) {
		this.gameID = gameID;
		this.numberToGuess = new int[4];
		this.guessedNumber = new int[4];
		this.status = false;
		generateAnswer();

	}

	public int getGameID() {
		return gameID;
	}

	public void setGameID(int gameID) {
		this.gameID = gameID;
	}

	public int[] getNumberToGuess() {
		return numberToGuess;
	}

	public void setNumberToGuess(int[] numberToGuess) {
		this.numberToGuess = numberToGuess;
	}

	public int[] getGuessedNumber() {
		return guessedNumber;
	}

	public void setGuessedNumber(int[] guessedNumber) {
		this.guessedNumber = guessedNumber;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public void generateAnswer() {
		Random rand = new Random();
		int upperbound = 9;
		// generate random values from 0-24
		for (int i = 0; i < 4; i++) {
			int int_random = 0;
			boolean tr = false;
			while (!tr) {
				int_random = rand.nextInt(upperbound);
				//System.out.println(int_random);
				boolean found = false;
				for (int j = 0; j < 4; j++) {
					if (this.numberToGuess[j] == int_random) {
						found = true;
					}
				}
				if (!found)
					tr = true;

			}
			this.numberToGuess[i] = int_random;
		}

	}

	@Override
	public String toString() {
		return "Game [gameID=" + gameID + ", numberToGuess=" + Arrays.toString(numberToGuess) + ", guessedNumber="
				+ Arrays.toString(guessedNumber) + ", status=" + status + "]";
	}

}
