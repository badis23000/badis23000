package com.guestTheNumber.guessTheNumber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuessTheNumberApplicationTests {

	@Test
	void contextLoads() {
	}

}
